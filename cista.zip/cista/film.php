<?php
session_start();

if (isset($_SESSION["UTENTE"])) {
    $servername = "";
    $username = "";
    $password = "";
    $dbname = "";
    
    require "credenziali.php";
    
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    // Verifica connessione
    if (!$conn) {
        die("Connessione al database fallita: " . mysqli_connect_error());
    }
    
    // Query per selezionare i dati dal database utilizzando i filtri
    $query = "SELECT * FROM cast";
    $result = mysqli_query($conn, $query);
    
    // Controllo se ci sono risultati
    if (mysqli_num_rows($result) > 0) {
        // Visualizzazione dei dati
        echo "Cast<br><table style='border:1px solid'><t><th>Nome</th></tr>";
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row["nome"] . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "Nessun risultato trovato.";
    }
    mysqli_close($conn);
} else {
    echo "Accesso non consentito";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cast</title>
</head>
<body>
    
</body>
</html>
