<?php
$servername = "localhost";
$username = "admin";
$password = "1234";
$dbname = "cista";
?>